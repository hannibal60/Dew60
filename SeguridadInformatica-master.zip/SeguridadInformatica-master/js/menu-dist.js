"use strict";

/*
	class = className
	Aqui no se reonoce el nombre de class por que es una palabra reservada de javascript para referirnos a una class de html usamos className
*/

var index = "index.html";
var el = React.createElement(
	"nav",
	{ className: "navbar navbar-expand-lg navbar-light bg-light" },
	React.createElement(
		"a",
		{ className: "navbar-brand", href: "#" },
		"SOITEC"
	),
	React.createElement(
		"button",
		{ className: "navbar-toggler", type: "button", "data-toggle": "collapse", "data-target": "#navbarSupportedContent", "aria-controls": "navbarSupportedContent", "aria-expanded": "false", "aria-label": "Toggle navigation" },
		React.createElement("span", { className: "navbar-toggler-icon" })
	),
	React.createElement(
		"div",
		{ className: "collapse navbar-collapse mr-sm-2", id: "navbarSupportedContent" },
		React.createElement(
			"ul",
			{ className: "navbar-nav mr-auto" },
			React.createElement(
				"li",
				{ className: "nav-item" },
				React.createElement(
					"a",
					{ className: "nav-link", href: index },
					"Inicio ",
					React.createElement(
						"span",
						{ className: "sr-only" },
						"(current)"
					)
				)
			),
			React.createElement(
				"li",
				{ className: "nav-item active" },
				React.createElement(
					"a",
					{ className: "nav-link", href: "nosotros.html" },
					"Sobre nosotros"
				)
			),
			React.createElement(
				"li",
				{ className: "nav-item" },
				React.createElement(
					"a",
					{ className: "nav-link", href: "#" },
					"Conctacto"
				)
			)
		)
	)
);

ReactDOM.render(el, document.getElementById('menu'));